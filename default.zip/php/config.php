<?php 

// CONTACT FORM RECIPIENT MAIL SETUP
define( 'CONTACT_FORM_RECIPIENT', 'example@email.net');

?>